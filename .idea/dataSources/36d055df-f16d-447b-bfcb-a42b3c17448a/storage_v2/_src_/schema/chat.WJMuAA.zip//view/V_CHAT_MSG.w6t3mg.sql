create definer = root@`%` view V_CHAT_MSG as
select `CM`.`ID`                AS `ID`,
       `CM`.`CHART_CMD`         AS `CHART_CMD`,
       `CM`.`CHART_STATUS`      AS `CHART_STATUS`,
       `CM`.`CHART_FROM_ID`     AS `CHART_FROM_ID`,
       `CM`.`CHART_FROM_CODE`   AS `CHART_FROM_CODE`,
       `CM`.`CHART_FROM_IP`     AS `CHART_FROM_IP`,
       `CM`.`CHART_ACCEPT_ID`   AS `CHART_ACCEPT_ID`,
       `CM`.`CHART_ACCEPT_CODE` AS `CHART_ACCEPT_CODE`,
       `CM`.`CHART_ACCEPT_IP`   AS `CHART_ACCEPT_IP`,
       `CM`.`CHART_GROUP_ID`    AS `CHART_GROUP_ID`,
       `CM`.`CHART_GROUP_CODE`  AS `CHART_GROUP_CODE`,
       `CM`.`CHART_MSG`         AS `CHART_MSG`,
       `CM`.`CHART_DATE`        AS `CHART_DATE`,
       `CG`.`ID`                AS `GROUP_ID`,
       `CG`.`GROUP_CODE`        AS `GROUP_CODE`,
       `CG`.`GROUP_NAME`        AS `GROUP_NAME`,
       `CU_FROM`.`USER_NAME`    AS `CHART_FROM_USER_NAME`,
       `CU_ACCEPT`.`USER_NAME`  AS `CHART_ACCEPT_USER_NAME`
from (((`chat`.`CHAT_MSG` `CM` left join `chat`.`CHAT_USER` `CU_FROM` on ((`CM`.`CHART_FROM_ID` = `CU_FROM`.`ID`))) left join `chat`.`CHAT_USER` `CU_ACCEPT` on ((`CM`.`CHART_ACCEPT_ID` = `CU_ACCEPT`.`ID`)))
         left join `chat`.`CHAT_GROUP` `CG`
                   on (((`CM`.`CHART_GROUP_ID` = `CG`.`ID`) or (`CM`.`CHART_GROUP_CODE` = `CG`.`GROUP_CODE`))))
order by `CM`.`CHART_DATE` desc;

-- comment on column V_CHAT_MSG.ID not supported: 主键

-- comment on column V_CHAT_MSG.CHART_CMD not supported: 状态0未发送 1已发送 -1删除

-- comment on column V_CHAT_MSG.CHART_STATUS not supported: 1.绑定上线 2.下线 3.单聊 4.群聊 5.获取用户信息 6获取群组用户信息

-- comment on column V_CHAT_MSG.CHART_FROM_ID not supported: 发送用户ID

-- comment on column V_CHAT_MSG.CHART_FROM_CODE not supported: 发送用户CODE

-- comment on column V_CHAT_MSG.CHART_FROM_IP not supported: 发送用户IP

-- comment on column V_CHAT_MSG.CHART_ACCEPT_ID not supported: 接收用户ID

-- comment on column V_CHAT_MSG.CHART_ACCEPT_CODE not supported: 接收用户CODE

-- comment on column V_CHAT_MSG.CHART_ACCEPT_IP not supported: 接收用户IP

-- comment on column V_CHAT_MSG.CHART_GROUP_ID not supported: 群组ID

-- comment on column V_CHAT_MSG.CHART_GROUP_CODE not supported: 群组CODE

-- comment on column V_CHAT_MSG.CHART_MSG not supported: 发送信息

-- comment on column V_CHAT_MSG.CHART_DATE not supported: 创建时间

-- comment on column V_CHAT_MSG.GROUP_ID not supported: 主键

-- comment on column V_CHAT_MSG.GROUP_CODE not supported: 组代码

-- comment on column V_CHAT_MSG.GROUP_NAME not supported: 组名称

-- comment on column V_CHAT_MSG.CHART_FROM_USER_NAME not supported: 用户昵称

-- comment on column V_CHAT_MSG.CHART_ACCEPT_USER_NAME not supported: 用户昵称

